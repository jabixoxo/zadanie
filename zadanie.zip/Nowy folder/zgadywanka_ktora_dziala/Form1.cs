﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace zgadywanka_ktora_dziala
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }


        int liczbaPoczatkowa;
        int liczbaDo;
        int licznik = 1;
        int wylosowana;


        private void txtZakres_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtWynik_TextChanged(object sender, EventArgs e)
        {

        }

        private void btn1_Click(object sender, EventArgs e)
        {
            if (txtWynik.Text == "Zgaduj" || txtWynik.Text == "Brawo za: " + licznik + "x")
                txtWynik.Text = "";
            if (jest_wylosowana && zakres_wybrany)
            {
                Zeruj();
                txtWynik.Text += "1";
            }
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            if (txtWynik.Text == "Zgaduj" || txtWynik.Text == "Brawo za: " + licznik + "x")
                txtWynik.Text = "";
            if (jest_wylosowana && zakres_wybrany)
            {
                Zeruj();
                txtWynik.Text += "2";
            }
        }

        private void btn3_Click(object sender, EventArgs e)
        {
            if (txtWynik.Text == "Zgaduj" || txtWynik.Text == "Brawo za: " + licznik + "x")
                txtWynik.Text = "";
            if (jest_wylosowana && zakres_wybrany)
            {
                Zeruj();
                txtWynik.Text += "3";
            }
        }

        private void btn4_Click(object sender, EventArgs e)
        {
            if (txtWynik.Text == "Zgaduj" || txtWynik.Text == "Brawo za: " + licznik + "x")
                txtWynik.Text = "";
            if (jest_wylosowana && zakres_wybrany)
            {
                Zeruj();
                txtWynik.Text += "4";
            }
        }

        private void btn5_Click(object sender, EventArgs e)
        {
            if (txtWynik.Text == "Zgaduj" || txtWynik.Text == "Brawo za: " + licznik + "x")
                txtWynik.Text = "";
            if (jest_wylosowana && zakres_wybrany)
            {
                Zeruj();
                txtWynik.Text += "5";
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (txtWynik.Text == "Zgaduj" || txtWynik.Text == "Brawo za: " + licznik + "x")
                txtWynik.Text = "";
            if (jest_wylosowana && zakres_wybrany)
            {
                Zeruj();
                txtWynik.Text += "6";
            }
        }

        private void btn7_Click(object sender, EventArgs e)
        {
            if (txtWynik.Text == "Zgaduj" || txtWynik.Text == "Brawo za: " + licznik + "x")
                txtWynik.Text = "";
            if (jest_wylosowana && zakres_wybrany)
            {
                Zeruj();
                txtWynik.Text += "7";
            }
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            if (txtWynik.Text == "Zgaduj" || txtWynik.Text == "Brawo za: " + licznik + "x")
                txtWynik.Text = "";
            if (jest_wylosowana && zakres_wybrany)
            {
                Zeruj();
                txtWynik.Text += "8";
            }
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            if (txtWynik.Text == "Zgaduj" || txtWynik.Text == "Brawo za: " + licznik + "x")
                txtWynik.Text = "";
            if (jest_wylosowana && zakres_wybrany)
            {
                Zeruj();
                txtWynik.Text += "9";
            }
        }

        private void btnStar_Click(object sender, EventArgs e)
        {
            if (zakres_wybrany)
            {
                txtWynik.Text = "Zgaduj";
                jest_wylosowana = true;
                Random rand = new Random();
                wylosowana = rand.Next(liczbaPoczatkowa, liczbaDo);
            }
        }

        private void btn0_Click(object sender, EventArgs e)
        {
            if (txtWynik.Text == "Zgaduj" || txtWynik.Text == "Brawo za: " + licznik + "x")
                txtWynik.Text = "";
            if (jest_wylosowana && zakres_wybrany)
            {
                Zeruj();
                txtWynik.Text += "0";
            }
        }

        private void btnZatwierd_Click(object sender, EventArgs e)
        {

            int liczba1 = 0;
            int liczba2 = 0;
            bool git = true;

            if (String.IsNullOrEmpty(txtZakresdol.Text) || String.IsNullOrEmpty(txtZakresgora.Text))
            {
                git = false;
                MessageBox.Show("prosze podac poprawny zakres");
              
            }

            // else if()
            else if (!Char.IsNumber(txtZakresdol.Text, 0) || !Char.IsNumber(txtZakresgora.Text, 0) || !Char.IsNumber(txtZakresdol.Text, 1) || !Char.IsNumber(txtZakresgora.Text, 1) || !Char.IsNumber(txtZakresdol.Text, 2) || !Char.IsNumber(txtZakresgora.Text, 2))
            {
                
                git = false;
                MessageBox.Show("prosze podac poprawny zakres");

            }

            else
            {
                liczba1 = Int32.Parse(txtZakresdol.Text);
                liczba2 = Int32.Parse(txtZakresgora.Text);
            }

            if (git == true)
            {
                if (liczba1 < 0 || liczba1 > 2147483645 || liczba2 < 1 || liczba1 == liczba2)
                {
                    MessageBox.Show("prosze podac poprawny zakres");
                }
                else if (liczba1 > -1 && liczba1 < 214783646 && liczba2 > 0 && liczba1 != liczba2)
                {
                    liczbaPoczatkowa = Int32.Parse(txtZakresdol.Text);
                    liczbaDo = Int32.Parse(txtZakresgora.Text);
                }
            }
            //liczba_od = Int32.Parse(txtZakresdol.Text);
           

          //  liczba_do = Int32.Parse(txtZakresgora.Text);

                /*
                if (liczba2 < 1 || liczba1 == liczba2)
                {
                    MessageBox.Show("prosze podac poprawna liczbe");
                }
                */
               // else if (liczba2 > 0 || liczba2 < 2147483647)


            zakres_wybrany = true;
            txtWynik.Text = "";
            licznik = 1;
        }

        private void btnHash_Click(object sender, EventArgs e)
        {
            if (zakres_wybrany)
            {
                try
                {
                    int wartosc = Int32.Parse(txtWynik.Text);
                    if (wartosc < liczbaPoczatkowa || wartosc > liczbaDo)
                    {
                        MessageBox.Show("prosze podac licze z zakresu");
                        txtWynik.Text = "";
                    }
                   else if (wylosowana == wartosc)
                    {
                        txtWynik.Text = "Brawo za: " + licznik + "x";
                        licznik = 1;
                    }
                  else if (wylosowana > wartosc)
                    {
                        txtWynik.Text = "za mala";
                        licznik++;
                    }
                   else if (wylosowana < wartosc)
                    {
                        txtWynik.Text = "za duza";
                        licznik++;
                    }
                }
                catch
                {
                    txtWynik.Text = "";
                }
            }

               

        }
        bool jest_wylosowana = false;
        bool zakres_wybrany = false;
        private void Zeruj()
        {
            if (txtWynik.Text.StartsWith("podaj zakres, nastepnie 'gwiazdke' zeby losowac"))
            {
                txtWynik.Text = "";
            }
            if (txtWynik.Text.StartsWith("za mala"))
            {
                txtWynik.Text = "";
            }
            if (txtWynik.Text.StartsWith("za duza"))
            {
                txtWynik.Text = "";
            }/*
            if (txtWynik.Text.StartsWith("brawo!"))
            {
                txtWynik.Text = "";
            }*/
        }
    }
}
